package test.syntax;

import junit.framework.TestCase;

public class WrongFromatOfCommandTest extends TestCase {

    public void testHasValidCommandFormat() {
	fail("Not yet implemented");
    }

}
