package test.syntax;

import junit.framework.TestCase;

public class WrongCommandTest extends TestCase {

    public void testIsValidCommand() {
	fail("Not yet implemented");
    }

}
