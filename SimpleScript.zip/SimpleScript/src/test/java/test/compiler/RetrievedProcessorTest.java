package test.compiler;

import junit.framework.TestCase;

public class RetrievedProcessorTest extends TestCase {

    public void testGetProcessor() {
	fail("Not yet implemented");
    }

}
