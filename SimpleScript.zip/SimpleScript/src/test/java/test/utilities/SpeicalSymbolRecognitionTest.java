package test.utilities;

import junit.framework.TestCase;

public class SpeicalSymbolRecognitionTest extends TestCase {

    public void testIsSpecialSymbol() {
	fail("Not yet implemented");
    }

}
